package com.team1.efep.enums;

public class Const {

    public final static String EMAIL_SUBJECT = "Flowerista: OTP Code To Verify Your Account";
    public final static String OTP_LINK = "http://localhost:8080/buyer/otp/verify?code=";
    public final static String EMAIL_SUBJECT_ORDER = "Flowerista: Order Notification";
}
