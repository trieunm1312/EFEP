package com.team1.efep.validations;

import java.util.HashMap;
import java.util.Map;

public class ViewOrderListValidation {
    public static Map<String, String> orderListValidation() {
        Map<String, String> error = new HashMap<>();
        return error;
    }
}
