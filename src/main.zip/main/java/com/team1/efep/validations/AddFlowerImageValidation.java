package com.team1.efep.validations;

import com.team1.efep.models.request_models.AddFlowerImageRequest;

import java.util.HashMap;
import java.util.Map;

public class AddFlowerImageValidation {
    public static Map<String, String> validate(AddFlowerImageRequest request) {
        Map<String, String> error = new HashMap<>();

        return error;
    }
}
