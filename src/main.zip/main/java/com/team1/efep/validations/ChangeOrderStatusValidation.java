package com.team1.efep.validations;

import com.team1.efep.configurations.MapConfig;
import com.team1.efep.models.request_models.ChangeOrderStatusRequest;

import java.util.HashMap;
import java.util.Map;

public class ChangeOrderStatusValidation {
    public static Map<String, String> validate(ChangeOrderStatusRequest request) {
        Map<String, String> error = new HashMap<>();
        return error;
    }
}
